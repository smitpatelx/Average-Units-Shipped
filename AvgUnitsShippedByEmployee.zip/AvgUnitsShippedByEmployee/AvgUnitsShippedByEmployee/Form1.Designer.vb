﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnits
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.lblUnitInput = New System.Windows.Forms.Label()
        Me.lbEmployee1 = New System.Windows.Forms.Label()
        Me.lblEmployee2 = New System.Windows.Forms.Label()
        Me.lblEmployee3 = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.tbInputUnits = New System.Windows.Forms.TextBox()
        Me.lblAverageOne = New System.Windows.Forms.Label()
        Me.lblAverageTwo = New System.Windows.Forms.Label()
        Me.lblAverageThree = New System.Windows.Forms.Label()
        Me.lblAvgPerDay = New System.Windows.Forms.Label()
        Me.ttInformation = New System.Windows.Forms.ToolTip(Me.components)
        Me.tbEmployeeOneOutput = New System.Windows.Forms.TextBox()
        Me.tbEmployeeTwoOutput = New System.Windows.Forms.TextBox()
        Me.tbEmployeeThreeOutput = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblDays
        '
        Me.lblDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDays.Location = New System.Drawing.Point(27, 19)
        Me.lblDays.Name = "lblDays"
        Me.lblDays.Size = New System.Drawing.Size(92, 43)
        Me.lblDays.TabIndex = 0
        Me.lblDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttInformation.SetToolTip(Me.lblDays, "This label will display days.")
        '
        'lblUnitInput
        '
        Me.lblUnitInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUnitInput.Location = New System.Drawing.Point(15, 94)
        Me.lblUnitInput.Name = "lblUnitInput"
        Me.lblUnitInput.Size = New System.Drawing.Size(66, 28)
        Me.lblUnitInput.TabIndex = 1
        Me.lblUnitInput.Text = "&Units:"
        Me.lblUnitInput.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbEmployee1
        '
        Me.lbEmployee1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbEmployee1.Location = New System.Drawing.Point(15, 128)
        Me.lbEmployee1.Name = "lbEmployee1"
        Me.lbEmployee1.Size = New System.Drawing.Size(154, 27)
        Me.lbEmployee1.TabIndex = 3
        Me.lbEmployee1.Text = "Employee 1:"
        Me.lbEmployee1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee2
        '
        Me.lblEmployee2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployee2.Location = New System.Drawing.Point(204, 128)
        Me.lblEmployee2.Name = "lblEmployee2"
        Me.lblEmployee2.Size = New System.Drawing.Size(154, 27)
        Me.lblEmployee2.TabIndex = 4
        Me.lblEmployee2.Text = "Employee 2:"
        Me.lblEmployee2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee3
        '
        Me.lblEmployee3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployee3.Location = New System.Drawing.Point(393, 128)
        Me.lblEmployee3.Name = "lblEmployee3"
        Me.lblEmployee3.Size = New System.Drawing.Size(154, 27)
        Me.lblEmployee3.TabIndex = 5
        Me.lblEmployee3.Text = "Employee 3:"
        Me.lblEmployee3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(15, 422)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(154, 36)
        Me.btnEnter.TabIndex = 13
        Me.btnEnter.Text = "&Enter"
        Me.ttInformation.SetToolTip(Me.btnEnter, "This is enter button to enter value.")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(212, 422)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(154, 36)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "&Reset"
        Me.ttInformation.SetToolTip(Me.btnReset, "This is reset button to reset the form.")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(393, 422)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(154, 36)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "&Exit"
        Me.ttInformation.SetToolTip(Me.btnExit, "This is exit button to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "exit this application.")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'tbInputUnits
        '
        Me.tbInputUnits.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbInputUnits.Location = New System.Drawing.Point(103, 94)
        Me.tbInputUnits.Name = "tbInputUnits"
        Me.tbInputUnits.Size = New System.Drawing.Size(118, 28)
        Me.tbInputUnits.TabIndex = 2
        Me.ttInformation.SetToolTip(Me.tbInputUnits, "This is the input textbox" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for users to enter the value.")
        '
        'lblAverageOne
        '
        Me.lblAverageOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageOne.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverageOne.Location = New System.Drawing.Point(15, 335)
        Me.lblAverageOne.Name = "lblAverageOne"
        Me.lblAverageOne.Size = New System.Drawing.Size(154, 29)
        Me.lblAverageOne.TabIndex = 9
        Me.lblAverageOne.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttInformation.SetToolTip(Me.lblAverageOne, "This label will display" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "average of first employee.")
        '
        'lblAverageTwo
        '
        Me.lblAverageTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageTwo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverageTwo.Location = New System.Drawing.Point(204, 335)
        Me.lblAverageTwo.Name = "lblAverageTwo"
        Me.lblAverageTwo.Size = New System.Drawing.Size(154, 29)
        Me.lblAverageTwo.TabIndex = 10
        Me.lblAverageTwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttInformation.SetToolTip(Me.lblAverageTwo, "This label will display" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "average of second employee.")
        '
        'lblAverageThree
        '
        Me.lblAverageThree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageThree.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverageThree.Location = New System.Drawing.Point(393, 335)
        Me.lblAverageThree.Name = "lblAverageThree"
        Me.lblAverageThree.Size = New System.Drawing.Size(154, 29)
        Me.lblAverageThree.TabIndex = 11
        Me.lblAverageThree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttInformation.SetToolTip(Me.lblAverageThree, "This label will display" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "average of third employee.")
        '
        'lblAvgPerDay
        '
        Me.lblAvgPerDay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAvgPerDay.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvgPerDay.Location = New System.Drawing.Point(12, 376)
        Me.lblAvgPerDay.Name = "lblAvgPerDay"
        Me.lblAvgPerDay.Size = New System.Drawing.Size(532, 34)
        Me.lblAvgPerDay.TabIndex = 12
        Me.lblAvgPerDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttInformation.SetToolTip(Me.lblAvgPerDay, "This label will display" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "average per day.")
        '
        'tbEmployeeOneOutput
        '
        Me.tbEmployeeOneOutput.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbEmployeeOneOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.tbEmployeeOneOutput.Location = New System.Drawing.Point(15, 158)
        Me.tbEmployeeOneOutput.Multiline = True
        Me.tbEmployeeOneOutput.Name = "tbEmployeeOneOutput"
        Me.tbEmployeeOneOutput.ReadOnly = True
        Me.tbEmployeeOneOutput.Size = New System.Drawing.Size(154, 159)
        Me.tbEmployeeOneOutput.TabIndex = 6
        Me.ttInformation.SetToolTip(Me.tbEmployeeOneOutput, "This box will display entries" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for employee 1.")
        '
        'tbEmployeeTwoOutput
        '
        Me.tbEmployeeTwoOutput.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbEmployeeTwoOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.tbEmployeeTwoOutput.Location = New System.Drawing.Point(204, 158)
        Me.tbEmployeeTwoOutput.Multiline = True
        Me.tbEmployeeTwoOutput.Name = "tbEmployeeTwoOutput"
        Me.tbEmployeeTwoOutput.ReadOnly = True
        Me.tbEmployeeTwoOutput.Size = New System.Drawing.Size(154, 159)
        Me.tbEmployeeTwoOutput.TabIndex = 7
        Me.ttInformation.SetToolTip(Me.tbEmployeeTwoOutput, "This box will display entries" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for employee 2.")
        '
        'tbEmployeeThreeOutput
        '
        Me.tbEmployeeThreeOutput.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbEmployeeThreeOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.tbEmployeeThreeOutput.Location = New System.Drawing.Point(393, 158)
        Me.tbEmployeeThreeOutput.Multiline = True
        Me.tbEmployeeThreeOutput.Name = "tbEmployeeThreeOutput"
        Me.tbEmployeeThreeOutput.ReadOnly = True
        Me.tbEmployeeThreeOutput.Size = New System.Drawing.Size(154, 159)
        Me.tbEmployeeThreeOutput.TabIndex = 8
        Me.ttInformation.SetToolTip(Me.tbEmployeeThreeOutput, "This box will display entries" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for employee 3.")
        '
        'frmAverageUnits
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(565, 470)
        Me.Controls.Add(Me.tbEmployeeThreeOutput)
        Me.Controls.Add(Me.tbEmployeeTwoOutput)
        Me.Controls.Add(Me.tbEmployeeOneOutput)
        Me.Controls.Add(Me.lblAvgPerDay)
        Me.Controls.Add(Me.lblAverageThree)
        Me.Controls.Add(Me.lblAverageTwo)
        Me.Controls.Add(Me.lblAverageOne)
        Me.Controls.Add(Me.tbInputUnits)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblEmployee3)
        Me.Controls.Add(Me.lblEmployee2)
        Me.Controls.Add(Me.lbEmployee1)
        Me.Controls.Add(Me.lblUnitInput)
        Me.Controls.Add(Me.lblDays)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAverageUnits"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmAverageUnits"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDays As Label
    Friend WithEvents lblUnitInput As Label
    Friend WithEvents lbEmployee1 As Label
    Friend WithEvents lblEmployee2 As Label
    Friend WithEvents lblEmployee3 As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents tbInputUnits As TextBox
    Friend WithEvents lblAverageOne As Label
    Friend WithEvents lblAverageTwo As Label
    Friend WithEvents lblAverageThree As Label
    Friend WithEvents lblAvgPerDay As Label
    Friend WithEvents ttInformation As ToolTip
    Friend WithEvents tbEmployeeOneOutput As TextBox
    Friend WithEvents tbEmployeeTwoOutput As TextBox
    Friend WithEvents tbEmployeeThreeOutput As TextBox
End Class
