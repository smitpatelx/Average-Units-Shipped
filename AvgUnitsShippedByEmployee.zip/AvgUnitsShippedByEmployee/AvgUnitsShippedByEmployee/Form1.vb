﻿'********************************************************************
'********************************************************************
'
'Name: smit patel
'Date: 03/03/2018
'Project: Lab-3 Average Units Shipped By Employee
'Course: NETD-2202-04 - NET DEVELOPMENT
'Description: This application takes user input and after validation it shows the input into the appropriate textbox and then it stores the value in array and also changes
'             day in the upper-corner. Then it will display average of that particular employee after their 7th entry. When user input last entry, it will show average
'             per day. Then user can also reset the application by "ESC" or by clicking reset button. User can also exit application by clicking exit button.
'
'********************************************************************
'********************************************************************
Option Strict On
Public Class frmAverageUnits

    Dim userInput As Integer = 0 'Declaration for users input to store values as Integer

    Private Const fixedEmployeeIndex As Integer = 6 'Defining fix row index as constant
    Private Const fixedDayIndex As Integer = 2 'Defining fix column as constant

    Private numberArray(fixedEmployeeIndex, fixedDayIndex) As Double

    Private currentDayIndex As Integer = 0 'Use to maintain current row index
    Private currentEmployeeIndex As Integer = 0 'Use to maintain current column index

    Dim averageOne As Double = 0.0 'Use to store average for first employee
    Dim averageTwo As Double = 0.0 'Use to store average for second employee
    Dim averageThree As Double = 0.0 'Use to store average for third employee
    Dim finalAverage As Double = 0.0 'Use to store final average per day

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close() 'Use to exit application

    End Sub

    Private Sub frmAverageUnits_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lblDays.Text = "Day 1" 'Use to display Day 1 when user start appication
        tbInputUnits.Focus() 'Use to set focus on input textbox

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        EnterFunction() 'Calls Enter subroutine when user click enter button

    End Sub

    Private Sub EnterFunction()

        Dim inputValues As String = tbInputUnits.Text 'Use to get input from user and declare it as String
        Dim sumTotal As Double = 0 'Use to declare sum of 7 days of all employees

        If Integer.TryParse(inputValues, userInput) Then

            userInput = Integer.Parse(inputValues) 'Use to Convert user input to integer

            If userInput < 0 Or userInput > 1000 Then

                tbInputUnits.SelectAll() 'Use to select all the text in input text box
                tbInputUnits.Focus() 'Use to set focus on input text box
                MessageBox.Show("The value must be between 0 to 1000.") 'Use to show error to users

            Else

                tbInputUnits.Clear() 'Use to clears the text in input text box
                tbInputUnits.Focus() 'Use to set focus on input text box

                numberArray(currentDayIndex, currentEmployeeIndex) = Double.Parse(inputValues)

                If currentEmployeeIndex = 0 Then 'For first column

                    lblDays.Text = "Day " + (2 + currentDayIndex).ToString 'To display Days according to array index
                    currentDayIndex += 1 'To increament row index by 1 on every click
                    tbEmployeeOneOutput.Text += inputValues + vbCrLf 'Use to display input values in text box one

                    If currentDayIndex > 6 Then 'To display average at 7th day

                        For SumCount As Integer = 0 To numberArray.GetUpperBound(0)
                            sumTotal += numberArray(SumCount, 0) 'For addition of all the values of first column
                        Next

                        averageOne = Math.Round(sumTotal / 7, 2) 'Use to Rounding average upto two decimal place
                        lblAverageOne.Text = "Average :" + averageOne.ToString 'Use to display average for first employee
                        currentEmployeeIndex += 1 'To increament column index by 1
                        currentDayIndex = 0 'Use to intialize row index
                        lblDays.Text = "Day 1" 'Use to display Day 1 for second employee input 

                    End If

                ElseIf currentEmployeeIndex = 1 Then

                    lblDays.Text = "Day " + (2 + currentDayIndex).ToString 'To display Days according to array index
                    currentDayIndex += 1 'To increament row index by 1 on every click
                    tbEmployeeTwoOutput.Text += inputValues + vbCrLf 'Use to display input values in text box one

                    If currentDayIndex > 6 Then 'To display average at 7th day

                        For SumCount As Integer = 0 To numberArray.GetUpperBound(0)
                            sumTotal += numberArray(SumCount, 1) 'For addition of all the values of first column
                        Next

                        averageTwo = Math.Round(sumTotal / 7, 2) 'Use to Rounding average upto two decimal place
                        lblAverageTwo.Text = "Average :" + averageTwo.ToString 'Use to display average for first employee
                        currentEmployeeIndex += 1 'To increament column index by 1
                        currentDayIndex = 0 'Use to intialize row index
                        lblDays.Text = "Day 1" 'Use to display Day 1 for second employee input

                    End If

                ElseIf currentEmployeeIndex = 2 Then

                    lblDays.Text = "Day " + (2 + currentDayIndex).ToString 'To display Days according to array index
                    currentDayIndex += 1 'To increament row index by 1 on every click
                    tbEmployeeThreeOutput.Text += inputValues + vbCrLf 'Use to display input values in text box one

                    If currentDayIndex > 6 Then

                        For sumCount As Integer = 0 To numberArray.GetUpperBound(0)
                            sumTotal += numberArray(sumCount, 2) 'For addition of all the values of first column
                        Next

                        averageThree = Math.Round(sumTotal / 7, 2) 'Use to Rounding average upto two decimal place
                        lblAverageThree.Text = "Average :" + averageThree.ToString 'Use to display average for first employee

                        finalAverage = Math.Round(((averageOne + averageTwo + averageThree) / 3), 2) 'Use to calculate final average
                        lblAvgPerDay.Text = "Average Per Day :" + String.Format(finalAverage.ToString, "0.00") 'display final average after formatting
                        lblDays.Text = "Done"

                        tbInputUnits.ReadOnly = True 'Use to set input text box as read only
                        btnEnter.Enabled = False 'Use to disable enter button
                        btnReset.Focus() 'Use to set focus to reset button

                    End If

                End If

            End If
        Else

            MessageBox.Show("The value must be numeric and a whole number.") 'To display error message if the input is not numerical
            tbInputUnits.SelectAll() 'Select all text from input text box
            tbInputUnits.Focus() 'Set focus on input text box 

        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Reset() 'Use to call reset subroutine

    End Sub

    Private Sub Reset()

        tbInputUnits.ReadOnly = False 'Use to remove readonly form input text box
        tbInputUnits.Clear() 'Use to clear input text box

        'use to clear output text box for all employees
        tbEmployeeOneOutput.Clear()
        tbEmployeeTwoOutput.Clear()
        tbEmployeeThreeOutput.Clear()

        'use to clear all output labels
        lblAverageOne.Text = String.Empty
        lblAverageTwo.Text = String.Empty
        lblAverageThree.Text = String.Empty
        lblAvgPerDay.Text = String.Empty

        btnEnter.Enabled = True 'Use to enable enter button
        tbInputUnits.Focus() 'use to set focus on input text box

        currentEmployeeIndex = 0 'initializing the employee index
        currentDayIndex = 0 'initializing day index

        lblDays.Text = "Day 1" 'Use to display Day 1 when reset application

    End Sub

End Class
